package com.dh.Odontologia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdontologiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
